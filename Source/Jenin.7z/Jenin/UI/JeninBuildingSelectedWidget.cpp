﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "JeninBuildingSelectedWidget.h"

#include "Jenin/Building/JeninBuilding.h"

// void UJeninBuildingSelectedWidget::NativeConstruct()
// {
// 	Super::NativeConstruct();
//
// 	if (AJeninBuilding *JeninBuilding = Cast<AJeninBuilding>(ActorReference))
// 	{
// 		BuildingNameText->SetText(JeninBuilding->BuildingName);
// 	}
//
// 	//BuildingImage->AddBinding()
// }


