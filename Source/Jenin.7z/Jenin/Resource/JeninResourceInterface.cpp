﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "JeninResourceInterface.h"


// Add default functionality here for any IJeninResourceInterface functions that are not pure virtual.
