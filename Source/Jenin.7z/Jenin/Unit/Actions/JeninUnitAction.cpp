﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "JeninUnitAction.h"

#include "Jenin/Core/JeninManagers/JeninUIManager.h"

void UJeninUnitAction::UnitActionExecution()
{

	
}

void UJeninUnitAction::UnitActionMouseOver()
{
	UnitActionExecution();
}

void UJeninUnitAction::InitUnitAction()
{




	// CREATE ACTION WIDGETS
	
	
	
	
	
}

void UJeninUnitAction::UnitActionDeExecution()
{


	
}

